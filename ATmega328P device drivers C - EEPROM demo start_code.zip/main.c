/********************************************************************************
* main.c: Demonstration av skrivning och l�sning till och fr�n EEPROM-minnet.
*         En tryckknapp ansluten till pin 13 (PORTB5). Vid nedtryckning av
*         tryckknappen l�ses inneh�llet p� adress 1000 i EEPROM-minnet och
*         skrivs ut i terminalen, f�ljt av att ineh�llet p� adressen
*         inkrementeras. En sekunds f�rdr�jning implementeras s� att
*         nedtryckning av tryckknappen medf�r en skrivning per sekund.
********************************************************************************/
#include "serial.h"
#include "button.h"
#include "eeprom.h"

/********************************************************************************
* main: Initierar systemet vid start med startv�rde 0 p� adress 1000 i EEPROM-
*       minnet, en tryckknapp p� pin 13 (PORTB5) samt seriell �verf�ring med
*       en baud rate (�verf�ringshastighet) p� 9600 kbps. Programmet h�lls sedan
*       ig�ng s� l�nge matningssp�nning tillf�rs, d�r tryckknappen l�ses av
*       kontinuerligt.
********************************************************************************/
int main(void)
{
   struct button b1;
   button_init(&b1, 13);

   /* Tilldela startv�rde 0 till EEPROM[1000:1001]. */
   serial_init(9600);
   
   while (1)
   {
      if (button_is_pressed(&b1))
      {
         /* L�s inneh�llet p� EEPROM[1000:1001]. */

         serial_print_string("Retrieved data from EEPROM: ");
         /* Skriv ut avl�st v�rde h�r! */
         serial_print_new_line();

         /* Skriv avl�st inneh�ll + 1 till EEPROM[1000:1001]. */
         delay_ms(1000);
      }
   }

   return 0;
}

